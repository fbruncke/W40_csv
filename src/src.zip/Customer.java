public record Customer (String name, String address, int houseNo) {}
